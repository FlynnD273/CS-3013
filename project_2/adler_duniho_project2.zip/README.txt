We first started out by reading through the two problems and figuring out which one we wanted to do. We decided on teh second problem because it seemed like the more definied of the two, and it looked a little more interesting to do. 

The next step was to make sure that we understood the thread creation logic. So we added just eh bare minimum needed to spawn all the plane threads and print out the plane number. 

After that, we added skeleton methods to establish how the planes would loop through and be controlled. Once completing that, we moved on to the actual threading logic. 
