//Reads a number from a given path and returns it as int
int readseed(const char *path);
